﻿// Env properties for development/local environment
module.exports  = {
    runport: 3000
}