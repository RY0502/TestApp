﻿// Env properties for production environment

module.exports = {
    runport: 8081
}