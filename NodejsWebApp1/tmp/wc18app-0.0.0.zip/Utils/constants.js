﻿//File for constants to be used across service and db layers

exports.NEXT = 'next';
exports.LAST = 'last';
exports.ALL = 'all';
exports.NEWS_API_KEY = '016c3f0ced384cbdab9e49b8942f1be3';
exports.NEWS_PARSE_KEYWORD = 'football';
exports.NEWS_TO_BE_DISPLAYED = 5;