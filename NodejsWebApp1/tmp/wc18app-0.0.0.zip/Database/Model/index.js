exports.dbFixtureModel = require('./Fixture');
exports.dbPlayerModel = require('./Player');
exports.dbTeamModel = require('./Team');
exports.dbNewsModel = require('./News');